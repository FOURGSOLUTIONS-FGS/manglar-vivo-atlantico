# Contenido para la ciudadanía

[P] Propuesta editorial y clasificación derivadas de A1–A3, bibliografía y conversación. No obliga a usar un menú ni a solicitar todos los datos.

## Vocabulario cotidiano

| Tema | Qué puede reconocer y comunicar | Información adicional si la conoce |
|---|---|---|
| Árboles afectados | Cortes, ramas secas, hojas amarillas, pérdida de hojas, árboles caídos | Cuántos, desde cuándo, si están cortando ahora |
| Agua | Espuma, color verde/negro, turbidez, malos olores, manchas | En agua o suelo, desde cuándo, extensión, si hay una descarga visible |
| Basura y contaminación | Plásticos, escombros, líquidos que salen de tuberías, manchas aceitosas | Tipo aparente, cantidad, ubicación, persistencia |
| Animales | Animales muertos, heridos o atrapados | Especie si la sabe, número aproximado, condición y ubicación |
| Terreno | Rellenos, pérdida de orilla, maquinaria, obras | Material, extensión, actividad presente o pasada |
| Circulación del agua | Caños bloqueados, agua desviada, agua estancada, secado o inundación inusual | Dónde, cambio respecto a antes, duración |
| Emergencias | Humo, llamas, tala en curso, mortandad múltiple, descarga activa peligrosa | Ubicación del hecho y si continúa; reportar sin exponerse |
| Vida del manglar | Aves, peces, cangrejos, mangles, brotes y plántulas | Cantidad, lugar, hora, especie opcional |
| Cuidado y recuperación | Siembras, limpiezas, regeneración, seguimiento comunitario | Fecha, lugar, qué se hizo y qué cambió después |

## Educación: contenido mínimo
- Qué es el manglar: ecosistema de transición donde influyen agua, suelo, vegetación, fauna y personas. El agua dulce y salada y la inundación varían por lugar.
- Por qué importa: protección costera, hábitat, pesca, almacenamiento de carbono, relación con comunidades. No presentar garantías de protección absoluta ni cifras económicas inventadas.
- Especies locales citadas por Hernando: mangle rojo (Rhizophora mangle, raíces de soporte), negro (Avicennia germinans, neumatóforos), blanco (Laguncularia racemosa, hojas con glándulas cerca del pecíolo), botón/zaragoza (Conocarpus erectus, frutos agrupados). Rasgos orientativos; no obligar a identificar especies ni garantizar identificación con una sola imagen.
- Qué observar: cambios visibles y observaciones positivas. No pedir diagnósticos de salinidad, nutrientes, oxígeno o contaminación química.
- Cómo contribuir: descripción propia, fotos seguras, ubicación real del fenómeno, hora aproximada, si continúa, magnitud si se conoce. Diferenciar lo visto personalmente de lo escuchado.
- Seguridad: no acercarse a fuego, maquinaria, agua contaminada ni presuntos infractores; no probar agua, tocar fauna o recoger muestras peligrosas. No exigir fotos si supone riesgo.
- Privacidad: explicar qué es anónimo frente a terceros y qué datos pueden ser visibles; no prometer anonimato absoluto si no se ha verificado.
- Retroalimentación: recibido no significa validado; pendiente no significa falso; derivado no significa resuelto. Diferenciar captura offline de recepción efectiva.

## Ejemplos de lenguaje ciudadano
«Vi varios peces muertos en la orilla»; «hoy el agua huele raro»; «hay un tronco cortado, no sé cuándo pasó»; «están tapando un caño»; «hoy vi dos garzas»; «las plántulas que sembramos siguen vivas». Todos tienen utilidad, pero diferente finalidad. Evitar que la ciudadanía tenga que usar los nombres técnicos internos.


[A4] La contribución mínima puede ser tomar y enviar una foto sin conocimiento especializado; el sistema debe distinguir lectura instrumental actual de última lectura disponible o desconocida. No exigir al ciudadano medir o diagnosticar. Ver 27.
