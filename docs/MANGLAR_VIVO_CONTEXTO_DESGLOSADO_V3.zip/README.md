# Manglar Vivo Atlántico — Contexto de dominio v3

Conocimiento por temas para ciudadanía, IA y CRA. No prescribe arquitectura, tareas ni implementación. Leer 00–01, revisar 20–25 (ampliación v2) y luego usar PROMPT_ACTUALIZACION.md con el repo y modelos actuales. El ZIP de fuentes contiene transcripciones, artículos, diapositiva y KMZ original.

## Índice
- `00_fuentes_y_criterios_de_certeza.md`
- `01_reto_y_necesidades_institucionales.md`
- `02_ecologia_y_especies.md`
- `03_contexto_territorial.md`
- `04_taxonomia_por_audiencia_y_repo.md`
- `05_diccionario_de_senales.md`
- `06_dimensiones_de_clasificacion.md`
- `07_limpieza_y_validacion_semantica.md`
- `08_corroboracion_y_eventos.md`
- `09_actuacion_CRA.md`
- `10_estaciones_QR_y_monitoreo.md`
- `11_familias_de_conocimiento.md`
- `12_casos_de_razonamiento.md`
- `13_bibliografia.md`
- `14_incertidumbres.md`
- `15_contenido_ciudadano.md`
- `16_modelos_visuales_y_fusion_de_evidencias.md`
- `17_respuestas_inferidas_y_decisiones_provisionales.md`
- `18_conservacion_participacion_y_resultados.md`
- `19_estado_actual_por_completar.md`
- `20_KMZ_prioridades_inventario_y_significado.md`
- `21_cuatro_especies_locales_y_reconocimiento.md`
- `22_investigacion_territorial_y_normativa.md`
- `23_investigacion_fisicoquimica_y_salud_ecosistemica.md`
- `24_investigacion_visual_y_catalogo_contenidos.md`
- `25_CAMBIOS_V2.md`
- `PROMPT_ACTUALIZACION.md`

Límites: no nuevo checkout del repo, no evaluación de modelos, no cotejo acústico, no verificación topológica ni de áreas del KMZ. No se confirma identidad entre sus polígonos, los cuatro del visor y los del repo. Investigación externa inicial, no revisión sistemática. Las propuestas no son protocolos oficiales. Ver 25.

## Complemento V3
- `26_CAMBIOS_V3.md`
- `27_apartado_cientifico_y_conexion_de_estaciones.md`
- `28_notificaciones_y_estado_operativo_declarado.md`
- `29_fuente_A4_extractos_relevantes.md`

Leer también estos documentos antes de ejecutar el prompt. Usar fuentes V2; los extractos de la nueva conversación están incluidos en 29.
