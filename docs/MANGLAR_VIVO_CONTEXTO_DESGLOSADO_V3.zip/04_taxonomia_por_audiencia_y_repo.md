# Manglar Vivo Atlántico | taxonomia por audiencia y repo

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 4. Ontología por capas: qué ve el ciudadano y qué comprende la CRA

[P] Las categorías no deben mezclar señal observable, causa, consecuencia, prioridad ni gestión administrativa. Conservar la clasificación actual como capa de compatibilidad, utilizar etiquetas más granulares internamente. Un reporte admite múltiples señales y observaciones. Una sola observación puede tener una categoría primaria y secundarias. Un evento puede tener muchas observaciones, incluso contradictorias. Un caso administrativo no equivale a una observación ni a un evento automático.

- Capa ciudadana: lenguaje común, texto libre, categoría opcional guiada, foto, ubicación, momento, actividad actual y magnitud si sabe. Puede desconocer términos técnicos. No mostrar códigos internos, ecuaciones ni diagnóstico sin verificar.
- Capa semántica: señal literal normalizada, medio afectado, objeto, acción, cantidad/unidad, temporalidad, negación, certeza declarada, fuente, evidencia y límites.
- Capa científica: proceso posible, hipótesis alternativas, condición de ecosistema, variables necesarias, interpretación por contexto, nivel de confirmación.
- Capa operativa CRA: afectación posible, urgencia, prioridad territorial, disponibilidad de evidencia, estado de corroboración, entidad sugerida y decisión humana.
- Capa administrativa: actuación, autoridad, asignación, inspección, resolución; distinguir alerta preliminar de oficial y expediente. No inventar normas ni números de artículos.

### 4.1 Compatibilidad con categorías actuales [R]

| Dominio | Subtipos existentes | Significado interno que debe mantenerse separado |
|---|---|---|
| cobertura_suelo | tala_poda, relleno_obra, quema_incendio | pérdida/intervención de cobertura, modificación de sustrato, evento térmico |
| agua_dosel | cano_taponado, dosel_seco, erosion_costera | conectividad hídrica, estado vegetal, dinámica geomorfológica |
| contaminacion | residuos_solidos, vertimiento_agua, derrame_combustible | residuos, señales de alteración del agua, posible hidrocarburo |
| fauna_verificacion | fauna_amenaza, avistamiento_fauna, verificacion_828ha | afectación animal, biodiversidad observada, verificación territorial |

El enum agregado del repositorio incluye tala_relleno, contaminacion_residuos, cambio_hidrico, dano_fauna_especies, otro. No inferir a partir del nombre que todo reporte `vertimiento_agua` prueba una descarga, ni `dosel_seco` prueba estrés salino, ni `tala_poda` demuestra ausencia de permiso. `verificacion_828ha` es una tarea territorial, no una amenaza; requiere observar también cobertura ausente, no visible o indeterminada. Esta granularidad complementaria es propuesta, no migración exigida.
