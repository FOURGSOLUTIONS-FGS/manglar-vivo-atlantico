# Manglar Vivo Atlántico | contexto territorial

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 3. Contexto espacial del prototipo

[R] Cuatro sectores definidos en `cra-domain.ts`: Mallorquín–Bocas de Ceniza; Puerto Colombia–Balboa–Puerto Velero; Tubará–Juan de Acosta; Totumo–Astilleros–Galerazamba. Los centroides son referencias, no ubicación exacta del evento. Las capas de preservación, restauración, recuperación y rehabilitación son contexto de gestión territorial, no gravedad actual.

El código distingue indicadores de cobertura probable, alta probabilidad, áreas por revisar, dosel seco, riesgo, vulnerabilidad y carbono. Los valores globales documentados incluyen 775 ha probables, 465 ha de alta probabilidad, 828 ha por revisar, 262 ha de dosel seco 2026, 524 puntos ground-truth, 9.408 polígonos costeros. No sumar áreas ni tratarlas como categorías disjuntas. No equiparar los ~300 ha mencionados oralmente por Hernando (estimación aproximada) con estas capas de distinta definición. Se requiere aclarar metodología, fechas, superposición y alcance. La cifra histórica de ~10.000 ha hace 200 años también es estimación oral. No convertir ninguna en inventario oficial sin fuente y fecha.

[P] Separar ubicación del observador, ubicación de captura, ubicación del fenómeno, precisión, dirección de cámara, geometría afectada y método de localización. La persona puede observar al otro lado del agua o desde el sendero, fuera del polígono. Una coordenada fuera de cobertura no invalida automáticamente: revisar cercanía, conectividad hídrica, jurisdicción y error GPS. Los puntos de referencia históricos no corroboran incidentes actuales; solo aportan contexto. Dirección de cámara no da por sí sola distancia ni extensión. Si existe incertidumbre espacial, conservarla. Registrar versión/fecha de capa y qué significado tiene la intersección.

## Reconciliación obligatoria con KMZ [K] y audio [A2]

Pamela, audio 08:58, parte 1, párrafo sobre «extensión», habla de cuatro polígonos visualizados en el visor de cobertura de manglar de la CRA. Mauricio, parte de preguntas, delimita el reto al corredor costero y menciona Puerto Colombia, Juan de Acosta, Tubará y Piojó. No pide capturar ni procesar satélites en el módulo ciudadano. Los cuatro sectores nombrados por el repo son su agrupación documentada; no se ha demostrado una correspondencia uno a uno con los cuatro polígonos del visor.

El KMZ aportado es una capa de prioridades de conservación más amplia: 14.732 registros, 17.182 polígonos, 5 nombres de subzonas hidrográficas, 97 nombres de unidades hidrográficas. Los 9.408 del repo son un conteo previo de su propia capa/selección; falta reconciliar origen, filtrado, versión y unidad de conteo. Los cuatro polígonos del visor no son los 14.732 registros de prioridades. Ver `20_KMZ_prioridades_inventario_y_significado.md` para datos exactos y `22_investigacion_territorial_y_normativa.md` para pendientes.

Distinguir: (1) ámbito departamental y jurisdicción; (2) zonas objetivo de monitoreo costero; (3) presencia/ausencia/cobertura probable de manglar; (4) prioridad de conservación; (5) acción territorial prevista; (6) fenómeno georreferenciado. Un reporte fuera de la cobertura puede afectar el manglar mediante un caño o cuerpo conectado. No clasificar como presencia de manglar basándose solamente en el KMZ de prioridades.
