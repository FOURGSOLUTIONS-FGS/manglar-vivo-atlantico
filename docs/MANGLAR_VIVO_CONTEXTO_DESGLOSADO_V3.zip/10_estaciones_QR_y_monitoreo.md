# Manglar Vivo Atlántico | estaciones QR y monitoreo

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 10. Fuentes instrumentales y monitoreo longitudinal

[A3,E] Hernando informa tres estaciones en Ecoparque, datalogger, interfaz y plataforma universitaria; también menciona una estación dentro del bosque. No inferir si esta última está incluida entre las tres. Indica que están inactivas y que podrían reactivarse. El equipo informa instalación el 13/12/2024, pendiente de corroboración en Anexo G3 completo. Diagrama documenta muelle, tubería eléctrica existente 110 VAC, caja de paso, datalogger, sensor EC/temperatura, pH, nivel y protector. Presentación lista conductividad y salinidad, temperatura, pH y nivel. Oxígeno disuelto se menciona oralmente como variable posible, pero no aparece en este diagrama. No afirmar que se mide actualmente. No se conocen coordenadas reales, API, formato de datos, cadencia, historial ni estado de calibración.

| Variable | Tipo de dato | Interpretación y límite |
|---|---|---|
| Conductividad | instrumental, unidad original | concentración iónica indirecta; depende de temperatura, no equiparar sin método a salinidad |
| Salinidad | instrumental/derivada con método | condiciones estuarinas; depende de especie, contexto y línea base; conservar unidad y método |
| Temperatura | instrumental °C u original | condiciones térmicas, influencia sobre metabolismo y oxígeno |
| pH | instrumental | condición ácido-base; no diagnostica contaminante |
| Nivel de agua | instrumental, m/cm con datum | inundación y dinámica; referencia vertical y marea necesarias |
| Oxígeno disuelto | posible ampliación | mg/L o saturación según instrumento; no deducible de imagen |
| Nitritos, nitratos y otros nutrientes | análisis o sensor específico | carga de nutrientes, no inferible de espuma |
| Clorofila | medición/remoto con método | aproximación a biomasa fitoplanctónica; no equivalente directo a nitratos |
| Sulfuros / redox | medición especializada | procesos geoquímicos; no convertir olor en concentración |
| Caudal | medición hidráulica | cantidad de agua por tiempo; no inferir de una foto estática |

[P] Guardar timestamp de medición, variable, valor, unidad, método, estación, sensor, calidad, mantenimiento, calibración y referencia espacial. Distinguir falta de señal de valor cero. Un valor atípico puede ser anomalía real o fallo; conservar y marcar. Asociar mediciones por tiempo, cobertura representativa y conectividad, no por proximidad sin más. Conservar línea base por estación, época y régimen de marea cuando esté disponible.

### 10.1 QR, escuelas, turistas y participación

[A3,N] La idea es instalar QR en puntos estratégicos, orientar fotos a hojas, agua, panorama y fauna y enlazarlas a estaciones cercanas. Propuesta de repetir cada 8 días, no obligación diaria; complementar con drones multiespectrales cada 15 días o mes según ejemplo del profesor. No afirmar que existen datos de drones públicos. Una estación QR es punto de observación humana, no necesariamente sensor. El QR no demuestra que el ciudadano estaba allí. La comparación requiere protocolo, campo de visión, hora/marea, esfuerzo y calidad similares; no calcular deterioro regional por número de reportes sin controlar exposición y esfuerzo. Escuela puede adoptar punto, turista hacer aporte breve, comunidad aportar conocimiento y seguimiento. Mostrar recepción y resultado de reportes sin revelar denunciantes ni datos sensibles. No incentivar cantidad de denuncias a costa de calidad. Registrar actividad de siembra separada de supervivencia y resultado; no convertir árboles sembrados en carbono capturado sin metodología.

### 10.2 Sostenibilidad institucional

Hernando y mentor comunitario explican que proyectos universitarios de monitoreo dejan estaciones y literatura gris pero pierden operación al acabar presupuesto. Se menciona iniciativa Uninorte con Conservación Internacional y CRA, estación meteorológica de precipitación y dificultades de coordinación CRA/Barranquilla Verde. No atribuir a una entidad obligación financiera específica sin confirmar competencia. El modelo de continuidad debe contemplar responsable institucional, mantenimiento, acceso a datos, financiación y transferencia técnica. Los sensores complementan la participación; Mauricio explícitamente advierte no eliminar el componente ciudadano.


[A4] Hernando confirma que el apartado fisicoquímico debe admitir estaciones conectadas y que una persona pueda fotografiar y enviar desde un punto con el valor monitoreado accesible. Ver 27 para significado y límites.
