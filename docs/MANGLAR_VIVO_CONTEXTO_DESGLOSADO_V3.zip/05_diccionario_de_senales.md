# Manglar Vivo Atlántico | diccionario de senales

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 5. Diccionario de señales ambientales

Las siguientes señales incluyen observaciones explícitas de las entrevistas y extensiones apoyadas por bibliografía o propuestas de diseño. Las hipótesis no son diagnósticos. Prioridades son orientativas salvo urgencias mencionadas expresamente por los profesionales.

| Señal en lenguaje común | Etiqueta semántica propuesta | Categoría actual relacionada | Hipótesis o significado | Información que discrimina |
|---|---|---|---|---|
| Están cortando árboles | corte_activo | tala_poda | remoción de cobertura | actividad ahora, árboles afectados, ubicación, especie si conocida |
| Hay troncos cortados | evidencia_corte | tala_poda | intervención pasada posible | frescura, extensión, fecha conocida, origen |
| Tiraron tierra o escombros | relleno_observado | relleno_obra | cambio del terreno, pérdida de hábitat | maquinaria, activo/pasado, extensión, material |
| Están haciendo una cerca/obra | infraestructura_observada | relleno_obra | intervención potencial | proximidad, actividad, permisos por consultar |
| Hay llamas | fuego_activo | quema_incendio | emergencia térmica | ubicación, propagación visible, actividad actual |
| Hay humo | humo_observado | quema_incendio | posible incendio | origen, llamas visibles, dirección, actualidad |
| Hay árboles quemados | evidencia_quema | quema_incendio | daño previo posible | área, fecha, persistencia de fuego |
| El caño tiene un muro o está tapado | obstruccion_visible | cano_taponado | pérdida de conectividad hídrica | ubicación de barrera, paso de agua, tipo de bloqueo |
| Desviaron el agua a una finca | desvio_reportado | cano_taponado | posible reducción de aportes | observación directa, dirección, conexión al manglar |
| El agua no se mueve | estancamiento_observado | cano_taponado | posible circulación reducida | duración, lugar, fase de marea, barrera visible |
| El suelo se secó / agua bajó | cambio_nivel_desecacion | cano_taponado / dosel_seco | régimen de inundación alterado o cambio natural | comparación previa, estación, nivel medido |
| Se inundó más de lo habitual | inundacion_observada | cambio_hidrico | pulso hídrico anómalo posible | duración, extensión, marea, lluvia |
| Las hojas están amarillas | amarillamiento | dosel_seco | estrés posible, no causa determinada | proporción, especie, fotos comparables |
| Se caen muchas hojas | defoliacion | dosel_seco | estrés posible, fenología alternativa | magnitud, duración, varios árboles, línea base |
| Casi no tiene hojas / ramas secas | perdida_follaje | dosel_seco | deterioro del dosel posible | vivo/muerto no concluyente, extensión |
| Árboles muertos de pie | mortalidad_vegetal_reportada | dosel_seco | daño biológico posible | confirmación técnica, extensión, tiempo |
| La orilla está retrocediendo | erosion_observada | erosion_costera | pérdida de sedimento | fotos repetidas, referencia física, marea |
| Raíces desenterradas, árboles caídos | socavacion_posible | erosion_costera | inestabilidad del borde | distinguir raíces aéreas naturales, tormenta, actividad humana |
| Hay arena acumulada | sedimentacion_observada | erosion_costera / cano_taponado | cambio geomorfológico, bloqueo posible | duración, ubicación, efecto sobre flujo |
| Hay plásticos en raíces o playa | residuos_visibles | residuos_solidos | contaminación sólida | tipo, área, volumen aproximado, ubicación |
| Sale líquido de un tubo | descarga_visible | vertimiento_agua | aporte externo, composición desconocida | flujo activo, color, olor reportado, ubicación de salida y receptor |
| Huele a aguas negras/huevo podrido | olor_reportado | vertimiento_agua | posible carga orgánica/sulfuro de hidrógeno, también origen natural | fuente visible, duración, contexto y medición |
| Hay mucha espuma | espuma_observada | vertimiento_agua | materia orgánica, actividad física u otros factores | extensión, persistencia, descarga, viento/oleaje |
| El agua de la laguna está verde | color_verde | vertimiento_agua / cano_taponado | posible proliferación algal/nutrientes/circulación reducida | medio laguna vs mar, comparación, clorofila y nutrientes si medidos |
| Hay agua turbia | turbidez_visual | vertimiento_agua | sedimentos u otros materiales | lluvia, oleaje, obras, persistencia, medición turbidez |
| Hay mancha negra | mancha_oscura | otro / vertimiento_agua provisional | medio o sustancia desconocidos | ¿agua o suelo?, extensión, foto, descarga |
| Hay brillo aceitoso / olor a combustible | pelicula_aceitosa / olor_combustible | derrame_combustible | posible hidrocarburo, no probado | fuente, superficie, persistencia, análisis técnico |
| Muchos peces muertos flotando | mortandad_peces_multiple | fauna_amenaza | evento agudo, anoxia/toxicidad u otras causas posibles | cantidad aproximada, área, otras especies, actividad reciente; avisar inmediatamente [A3] |
| Un animal muerto | mortalidad_individual | fauna_amenaza | caso aislado o señal incipiente | especie, circunstancia, otros animales; no descartar especie sensible |
| Muchos animales muertos | mortalidad_multiple | fauna_amenaza | evento de mortalidad potencialmente grave | especie, magnitud, patrón espacial, momento |
| Animal herido, atrapado | fauna_en_riesgo | fauna_amenaza | necesidad de atención de fauna | especie probable, ubicación segura, condición; no manipular |
| Vi aves, garzas, peces o cangrejos | presencia_fauna | avistamiento_fauna | biodiversidad observada, posible indicador positivo contextual | cantidad, esfuerzo, especie, hora, hábitat |
| Hoy no vi aves | no_deteccion_fauna | avistamiento_fauna | no detección, no prueba de ausencia o deterioro | esfuerzo y protocolo comparables, visitas repetidas |
| Aquí hay manglar vivo | cobertura_presente | verificacion_828ha | verificación territorial positiva localizada | punto, panorama, fecha, identidad probable |
| No hay manglar / no alcanzo a verlo | cobertura_ausente_reportada / no_visible | verificacion_828ha | verificación negativa o no evaluable, distintas | campo de visión, ubicación, acceso, fecha |
| Hay brotes o plántulas | regeneracion_observada | verificacion_828ha | regeneración posible | especie, conteo, ubicación, origen natural/siembra desconocido |
| Sembramos o limpiamos | accion_conservacion_reportada | participación | actividad registrada, no resultado probado | actor, fecha, área, especie, cantidad, plan y seguimiento |

Notas de rigor: Hernando vincula exceso de espuma con proteína y nutrientes; tratar esa explicación como pista de investigación, no lectura cuantitativa de nitratos/nitritos. Menciona aves/garzas como indicio general y ejemplos de una rata versus 50; no convertir 50 en umbral universal ni diagnosticar veneno. Recomienda fotos a hojas, árboles, agua de laguna, fauna y áreas circundantes cada ocho días en puntos repetidos. No pedir probar agua, acercarse a vertimientos, incendios, maquinaria o personas presuntamente infractoras. Las señales marcadas como extensiones (turbidez, película aceitosa, residuos específicos, no detección, etc.) no son todas enunciadas literalmente por el mentor; forman una interpretación operativa del dominio y del repo.
