# Manglar Vivo Atlántico | corroboracion y eventos

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 8. Resolución de eventos y corroboración

[P] Reporte = envío; observación = afirmación sobre fenómeno; evento = fenómeno candidato que puede agrupar observaciones; caso = unidad de gestión de autoridad. No crear un caso por cada foto automáticamente. Asociar por distancia compatible con precisión y fenómeno, tiempo, medio, señal y características del lugar. En agua puede importar conectividad hidráulica más que distancia euclídea. No fijar radios/ventanas oficiales sin evidencia. Conservar cada fuente y contradicción; admitir separación posterior de eventos agrupados erróneamente. Reenvíos, imágenes idénticas o reportes coordinados no suman evidencia independiente. Anonimato no equivale a falta de credibilidad. Un único testigo puede justificar revisión urgente. Ground-truth histórico confirma contexto de cobertura, no incidente actual. Sensor cercano no implica misma masa de agua ni causa común.

Ejemplo: tres personas reportan peces muertos y agua verde en lugar y hora compatibles; una estación registra cambio fisicoquímico. El sistema puede presentar un evento candidato con respaldo múltiple, sin declarar eutrofización, envenenamiento ni causalidad. Si dos fotos son idénticas, el respaldo visual es una sola evidencia. Una observación de agua normal en otro punto no descarta el evento.
