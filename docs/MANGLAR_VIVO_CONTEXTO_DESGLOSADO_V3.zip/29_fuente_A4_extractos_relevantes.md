# [A4] Extractos relevantes de la conversación adicional

Fuente: transcripción textual aportada directamente por Enmanuel el 27/11/2026. Hora de grabación no identificada. No cotejada con audio. Se preservan extractos literales pertinentes al reto; se omiten conversaciones personales y paralelas no relacionadas.

**Hernando:** «...un espacio para parámetros fisicoquímicos, científicos, toda esa vaina que llegue ahí de este tipo de estación.»

**Hernando:** «Que simplemente se conectan y ya, es que no tiene que... eso es un apartado de la... ¿cómo se llama? Eso debe estar en el software.»

**Enmanuel:** «Okay. Eh... vamos a implementar datos de... de salud de agua. Hay repos públicos y tal. Sí, podemos hacer eso, es sencillo.»

**Hernando:** «Oye, ahí te mandé... te mandé la última publicación.»

**Compañero:** «...y también lo configuré para que mande, digamos cuando son alertas muy graves, que las mande por correo.»

**Enmanuel:** «Tenemos que tratar de vincular el correo... ¿Y cómo envían el correo?»

**Compañero:** «A través de... yo tengo ya un dominio comprado...»

**Enmanuel:** «Porque pueden usar Twilio para las llamadas, mensajes de texto...»

**Compañero:** «Pero yo prefiero Telnyx que es el proveedor que está por detrás de Twilio.»

**Enmanuel:** «¿Por ejemplo tú usas Twilio para los mensajes y usas SendGrid para los correos?»

**Compañero:** «Yo acá tengo mi propio... sale más barato comprar en Telnyx... ya acá tengo mi propio de llamadas, eso es para la parte de...»

**Hernando:** «Ah, yo tengo unos papers en... ¿cómo se llama?, en Internet de las Cosas. También hice un poquito de eso, pero no... sino armamos un proyecto para tomar... bueno, por eso fue toda esa vaina de las estaciones y eso. ¿Tú bajaste esos papers también?»

**Enmanuel:** «Mire. Yo lo que hice fue coger sus investigaciones relevantes con los manglares, y ahí metí a Tree of Science, de pronto usted conoce esta página. Y de allí... espérame un momento... de allí empecé a sacar otros papers relacionados con las cosas de los manglares.»

**Hernando:** «Pero esa vaina que lo maneje una persona que pase por ahí que no sepa...»

**Enmanuel:** «No, no, no. Es que la persona lo único que tiene que hacer es tomar fotos.»

**Hernando:** «Exacto, que eso tenga como un botón y salga el valor que está monitoreando en ese momento, que la persona le tome foto y lo mande, pero eso debe estar, debería estar conectado a la plataforma.»

**Enmanuel:** «Así es, sí, es la idea. Siempre fue la idea desde el inicio.»
