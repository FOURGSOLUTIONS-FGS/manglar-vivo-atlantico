# Apartado científico y conexión de estaciones — complemento de entrevista [A4]

## Solicitudes explícitas de Hernando
- Reservar un espacio propio para parámetros fisicoquímicos y científicos que puedan llegar de estaciones externas conectadas a la plataforma.
- La persona que pasa por el manglar no tiene que saber de ecología ni introducir parámetros técnicos; puede limitarse a tomar una fotografía y enviarla.
- En un punto de monitoreo, hacer accesible el valor que se está midiendo en ese momento, asociado a la fotografía y al contexto del punto. El valor debe provenir de la plataforma conectada, no de estimación visual.

## Contenido científico diferenciado por audiencia [P]
| Ciudadanía | CRA / investigación |
|---|---|
| Qué se mide y por qué importa | Variable, método, unidad, medio y procedencia |
| Última medición disponible con fecha y estado | Serie temporal, calidad, calibración, estación y contexto |
| Explicación sencilla, sin diagnóstico automático | Rango histórico local, anomalía, incertidumbre y límites |
| Foto opcional de observación en el punto | Vinculación temporal y espacial con lectura y evidencia |

No exigir transcripción manual del sensor. Si no hay conexión, indicar si el valor es histórico, último disponible o no disponible; no presentarlo como actual. Una lectura externa debe distinguirse de una medición propia. No asociar estaciones por distancia únicamente: considerar conectividad hídrica, tipo de agua y hora.

Variables documentadas en [E]: conductividad, salinidad, temperatura, pH y nivel. Oxígeno disuelto y demás variables son posibles extensiones, no sensores confirmados. La solicitud de conexión no confirma que la estación actualmente esté activa o que exista una API disponible.

## Investigación a complementar
Enmanuel expresa intención de usar repositorios públicos de salud/calidad del agua. No consta qué repositorios encontró ni que ya estén conectados. Investigar fuentes oficiales y científicas (por ejemplo INVEMAR/REDCAM, IDEAM y datos abiertos de Colombia, como candidatos a comprobar), cobertura efectiva de Mallorquín y demás sectores objetivo, estaciones, fechas, unidades, medio de muestra, métodos, calidad, licencia y modalidad de acceso. No presentar un dato regional, marino o continental como medición puntual de manglar; distinguir históricos de datos en vivo. Si se calcula un índice de calidad, documentar metodología y aplicabilidad al medio estuarino; no inventar un índice ni reutilizar umbrales de agua potable.

Hernando menciona publicaciones propias sobre Internet de las Cosas vinculadas a la investigación y estaciones. Buscar por autor, afiliación, título y DOI, verificar texto completo y extraer información instrumental; no inventar publicaciones ni asumir que todos sus artículos fueron entregados. También menciona que envió su publicación más reciente, sin identificarla en este fragmento; verificar si coincide con la referencia de 2025 ya incluida.
