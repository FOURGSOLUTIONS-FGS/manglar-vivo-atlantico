# Manglar Vivo Atlántico | incertidumbres

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 14. Vacíos que requieren confirmación de dominio, no decisiones de programación

1. ¿La CRA quiere tratar reportes con urgencia preliminar antes de aval de mentores? ¿Quién y cómo emite la alerta oficial?
2. ¿Cuáles son los criterios, definiciones y niveles oficiales de prioridad territorial? ¿Qué significan exactamente las capas 775/465/828/262 ha y sus diferencias con la estimación oral de ~300 ha?
3. ¿Qué campos mínimos requiere cada tipo de actuación y cuáles se pueden completar después? ¿Qué ocurre si falta imagen o GPS pero existe emergencia plausible?
4. ¿Cuál es la jurisdicción de CRA, Barranquilla Verde y municipios por zona y fenómeno? ¿Nombre completo, funciones y canal del Grupo PRIA? ¿Canales institucionales habilitados para Bomberos y Policía Ambiental?
5. ¿Cuáles son los identificadores, coordenadas y estado operativo de estaciones? ¿Qué variables efectivamente miden, frecuencia, unidad, calibración, API e histórico? ¿La estación del bosque es una de las tres?
6. ¿Existen protocolos de monitoreo por especie, zona, época/marea y variable? ¿Rangos de referencia o umbrales de intervención locales documentados? ¿Cómo distinguir señales normales de anómalas?
7. ¿Cuál es la regla de anonimato y publicación de datos? ¿Qué evidencias pueden ver ciudadanía, mentores y CRA? ¿Cómo preservar seguridad de denunciantes?
8. ¿Cómo debe distinguirse registro de actor/acción, observación ambiental y denuncia? ¿Qué normativa oficial y permisos pueden consultarse para que el asistente los cite sin inventar?

Hasta resolver estos vacíos, conservar estados indeterminados, utilizar hipótesis explícitas, permitir validación humana, no atribuir oficialmente prioridades propuestas ni presentar datos simulados como observados.

## Investigación organizada
Los documentos 21–24 convierten los vacíos en preguntas de investigación concretas. Priorizar evidencia local y fuentes oficiales, identificar el estado de cada hallazgo (verificado / inferido / pendiente). 20 resuelve conteos y atributos del KMZ, pero no su metodología. No asumir que la cartografía de prioridades equivale a cobertura de manglar ni que la versión del repo coincide con [K].
