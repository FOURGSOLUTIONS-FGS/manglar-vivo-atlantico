# Manglar Vivo Atlántico | bibliografia

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 13. Bibliografía: conocimiento complementario aportado

Los PDFs repetidos no cuentan como corroboración independiente. Se han consultado resúmenes y pasajes pertinentes, no auditado integralmente metodología de todos los artículos.

- Sánchez-Moreno et al. (2019), Influencia de los impactos antrópicos sobre la evolución del bosque de manglar en Puerto Colombia (275-Texto...). Reducción de aportes de agua dulce por modificación de arroyos y erosión ligada a espigones; ancho de bosque de 134 m (2004) a 24 m (2017) en el área de estudio. Restauración requiere recuperar condiciones hídricas y sedimentarias, no solo plantar. Proponen R. mangle hacia mar y A. germinans hacia tierra para ese caso; no aplicar mecánicamente en todo el departamento.
- Villate Daza et al. (2020), Mangrove Forests Evolution and Threats in the Caribbean Sea of Colombia (water-12-01113.pdf). Landsat: pérdidas históricas 15 ha Mallorquín y 301 ha Totumo (1985–2018), 31 ha La Virgen (2013–2018). Factores hidrológicos, tala, urbanización, erosión y usos agropecuarios según lugar. No usar como estado actual ni como áreas de los sectores del repo.
- Chacón Abarca et al. (2020), Bosques de manglar del Caribe Norte Colombiano: Análisis, evolución y herramientas de gestión (289-Texto...). Carreteras, urbanización turística, espigones, obras hidráulicas, deforestación y fenómenos naturales como El Niño y huracán Mitch; gestión a distintas escalas. No confundir la mención de El Niño con pronóstico vigente confirmado.
- Agudelo et al. (2015), Estructura y composición florística de los manglares de la bahía de Cispatá (0034-7744...). Estudia diámetro, altura, densidad, inundación, salinidad intersticial, pH del suelo, nutrientes, raíces y densidad aparente. Distingue cuenca y borde, con cambios por intervención humana. Refuerza necesidad de contexto y no umbrales uniformes.
- Álvarez-León (2003), Los manglares de Colombia y la recuperación de sus áreas degradadas (61790101.pdf). Revisión de especies y experiencias de regeneración, propagación y restauración. No equiparar cualquier especie con idoneidad en todo lugar.
- Valero, Barraza y Medina (2011), Un escenario para el uso de microorganismos del manglar como inoculantes microbianos en Colombia (Dialnet...). Microorganismos en reciclaje de nutrientes y potencial para establecimiento de plántulas; no inferir comunidad microbiana de fotos, no proponer inoculantes como medida automática.
- Polanía, Urrego y Agudelo (2015), Recent advances in understanding Colombian mangroves (1-s2.0-S1146609X15000120-main.pdf). Métodos remotos, parcelas, sedimentos, polen; dinámicas temporales y espaciales y gradientes múltiples de perturbación. Relevante para monitoreo longitudinal y comparabilidad.
- Osland et al. (2018), Mangrove forests in a rapidly changing world (1-s2.0-S0272771418301811-main.pdf). Golfo de México: clima, nivel del mar, ciclones, eutrofización, uso del suelo y otros factores interactúan; no extrapolar parámetros al Atlántico colombiano sin datos.
- Barbier (2016), The protective service of mangrove ecosystems: A review of valuation methods (1-s2.0-S0025326X16300224-main.pdf). Protección y valoración por daños evitados; no monetizar impacto con coeficientes inventados.

## Ampliación v2
Véanse las referencias enlazadas en 21–24: Alcaldía de Barranquilla (cuatro especies), artículo local Scientific Reports 2025 DOI 10.1038/s41598-025-10278-6, MinAmbiente Resolución 1263 de 2018 y lineamientos, INVEMAR SIGMA, guía nacional de restauración y portafolio CRA como pista cartográfica. Se han consultado páginas web y resultados pertinentes; no se ha realizado una revisión sistemática ni leído integralmente todos los anexos normativos.
