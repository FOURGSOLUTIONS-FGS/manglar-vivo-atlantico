# Conocimiento para los modelos visuales y la interpretación multimodal

Estado conocido por declaración del equipo: un compañero está entrenando modelos visuales con datasets públicos. No se han recibido nombres de datasets, etiquetas, código de entrenamiento, métricas ni pesos. Las clases siguientes son necesidades del dominio, no capacidades ya implementadas.

## Familias de objetos y condiciones de interés
| Objeto/medio | Señales visuales candidatas | No inferir automáticamente |
|---|---|---|
| Árbol, hoja, dosel | Pigmentación, densidad, defoliación, ramas secas, cortes, plántulas | Especie cierta, estrés salino, muerte irreversible |
| Raíces y orilla | Raíces de soporte, neumatóforos, cortes, pérdida visible de sustrato, retroceso | Erosión por raíces visibles normales; causa de retroceso |
| Agua | Espuma, turbidez aparente, color verde u oscuro, película superficial, descarga | pH, salinidad, concentración de nitratos, toxicidad, hidrocarburo confirmado |
| Fauna | Aves, peces, crustáceos, animales aparentemente muertos/heridos/atrapados | Envenenamiento, ausencia ecológica, especie exacta sin evidencia |
| Infraestructura y maquinaria | Tuberías, flujo visible, relleno, construcción, excavadora, vehículo | Ilegalidad, autoría, permisos o actividad en curso a partir de foto aislada |
| Fuego | Humo, llamas, áreas aparentemente quemadas | Incendio activo actual si la imagen es antigua o el origen no es visible |
| Residuos | Plásticos, botellas, bolsas, escombros | Composición química, masa o volumen sin escala |

## Correspondencias de ejemplo (no etiquetas confirmadas del entrenamiento)
`fire` → llama visible; `smoke` → humo; `plastic` → residuo plástico; `dead_fish` → pez aparentemente muerto; `yellow_leaf` → pigmentación amarilla; `oil_spill` → apariencia compatible con película oleosa; `deforestation` → posible pérdida de cobertura; `algae` → posible presencia de algas; `bird` → avistamiento; `mangrove` → vegetación posiblemente de manglar. Cada correspondencia debe revisarse con la definición real de las etiquetas.

## Negativos difíciles y casos ambiguos
- Hojarasca natural vs. defoliación extensa; senescencia vs. estrés; raíces naturales vs. socavación.
- Espuma por oleaje vs. alteración del agua; reflejo/sombra vs. mancha; materia orgánica natural vs. vertimiento.
- Pez vivo fuera de agua o inmóvil vs. muerto; una muerte vs. evento múltiple.
- Obra autorizada vs. intervención no autorizada (imposible determinar solo visualmente).
- Manglar no visible por encuadre vs. ausente en el área.
- Humo lejano vs. incendio en manglar; foto antigua vs. situación actual.
- Imágenes borrosas, nocturnas, sobreexpuestas, fuera de dominio o con objetos pequeños.

## Evidencia visual vs. inferencia ambiental
La etiqueta original y la confianza del modelo se conservan como predicciones, no como verificación. Las probabilidades del modelo no son probabilidad de veracidad del reporte ni gravedad. No extrapolar a Atlántico las métricas de datasets públicos; registrar prueba local cuando exista. Diferenciar identificación, detección, segmentación y estimación de cantidad/área según capacidad efectivamente demostrada. El modelo puede abstenerse o reconocer evidencia insuficiente. No presentar medidas exactas a partir de fotos sin referencia de escala.

## Fusión de fuentes
Texto aporta olor, hora, contexto, testimonio; imagen aporta rasgos visibles; GPS aporta ubicación con incertidumbre; capa territorial aporta contexto; sensores aportan mediciones contextualizadas; otros reportes aportan posible corroboración; técnico aporta revisión. Si el texto afirma un derrame y la foto solo muestra agua oscura, conservar ambos sin convertir la hipótesis en hecho. Si una foto no muestra fuego, no desmentir necesariamente un aviso de incendio: puede no estar en el encuadre. Si varias imágenes son la misma pieza reenviada, no contarlas como fuentes independientes.

## Información que debe completar el compañero
Por cada modelo: propósito, tipo de tarea, clases exactas y definiciones, fuente y versión de datasets, cobertura geográfica y licencia, positivos y negativos, partición y posibles duplicados/fugas, resultados por clase y conjunto de evaluación, evidencia local si existe, limitaciones, abstención, correspondencia con señales ambientales, clases sin cobertura, salidas realmente disponibles y estado actual (entrenado/probado/en curso/propuesto). No inventar métricas. El significado de estas salidas es conocimiento de dominio; las decisiones técnicas son del equipo.

## Restricción territorial y taxonómica v2
Las cuatro especies objetivo están detalladas en 21. Comparar con clases reales de los datasets, permitir desconocido y vegetación no objetivo. El KMZ de prioridades no puede servir de etiqueta positiva de presencia de manglar. Una clasificación visual no acredita la pertenencia del punto a una cobertura real; usar la información territorial como contexto separado. Ver 24 para investigación y reconciliación de etiquetas.
