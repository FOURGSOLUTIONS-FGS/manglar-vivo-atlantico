# Investigación científica: parámetros, señales, salud y límites de inferencia

## Evidencia local incorporada [W]
- Villate Daza et al. (2020), *Mangrove Forests Evolution and Threats in the Caribbean Sea of Colombia*, https://www.mdpi.com/2073-4441/12/4/1113 (también en bibliografía original). Reporta salinidad intersticial de 14–50 ‰ en Mallorquín para el contexto de ese estudio; no es rango actual ni umbral de alerta. Distinguir agua intersticial/suelo y agua superficial.
- *Impact of soil salinity on structural attributes and above ground biomass carbon in a mangrove community of a Colombian Caribbean Coast*, Scientific Reports (2025), https://doi.org/10.1038/s41598-025-10278-6 . Reporta diferencias entre estaciones río, mar y laguna, con mayor salinidad del suelo en laguna, y asociaciones con composición y estructura vegetal; condiciones de menor salinidad se asociaron con árboles mayores y más carbono aéreo. No trasladar sus estaciones de muestreo a los tres dataloggers de Hernando sin demostrar identidad. Revisar método y datos originales antes de extraer valores cuantitativos adicionales.
- [A3] Hernando menciona 80 partes por mil para Avicennia como ejemplo de tolerancia; no usar como umbral de mortalidad o condición óptima. Los valores de otros estudios varían por especie, exposición, medio, método y estadio.

## Qué investigar por variable
| Variable o proceso | Contenido necesario | Restricción de interpretación |
|---|---|---|
| Salinidad/conductividad | Diferencias entre agua superficial/intersticial/suelo, temperatura de referencia, rangos por especie y estación | Conductividad no es salinidad sin método de conversión; ‰ y PSU no son intercambiables automáticamente. |
| pH | Medio, método, variación diurna y estacional, referencias locales | No universalizar límites de agua potable a estuarios. |
| Temperatura | Agua/aire/sedimento, ciclo diario, cambios agudos | La temperatura ambiente no sustituye la del agua. |
| Oxígeno disuelto | mg/L, saturación, temperatura, hora, hipótesis de hipoxia | No confirmado en el diagrama de estación; no inferir concentración por foto. |
| Nivel, caudal y marea | Datum, profundidad, inundación, relación con caños y estacionalidad | Nivel sin referencia temporal/vertical tiene utilidad limitada. |
| Nitrógeno, fósforo, clorofila, turbidez | Método, unidades, relación con proliferación y materia orgánica | Color y espuma no prueban concentración ni contaminación. |
| Sulfuros y redox | Medio, potencial redox, procesos microbianos, fitotoxicidad | Olor no prueba causa ni concentración. |
| Dosel y condición vegetal | Cobertura, pigmentación, defoliación, mortalidad, regeneración, protocolos repetibles | No clasificar salud integral con una imagen aislada. |
| Fauna | Especies locales, abundancia y esfuerzo de observación, migración, mortalidad | Ausencia de avistamiento no demuestra ausencia real. |
| Restauración | Referencia ecológica, hidrología, supervivencia, regeneración y resultados | Número sembrado no equivale a recuperación. |

## Entregable de investigación
Por hallazgo: afirmación, especie, lugar, fecha, unidad, tipo de muestra, método, tamaño de muestra si consta, rango observado vs tolerancia vs óptimo vs umbral, limitaciones, referencia exacta. Priorizar estudios Atlántico/Mallorquín; marcar otros ecosistemas como analogías. Identificar fuentes de series históricas, calibración de sensores y vigencia operativa. No inventar cifras ni umbrales de alarma, no confundir mediciones reales y simuladas. Revisar guía de restauración y lineamientos nacionales desde sus originales. No convertir esta investigación en tareas de ingeniería.


[A4] Investigar repositorios públicos de calidad de agua y publicaciones IoT del profesor; verificar alcance territorial, método, fecha, licencia y condiciones de acceso. Ver 27.
