# Manglar Vivo Atlántico | familias de conocimiento

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 11. Familias de datos para conocimiento de la IA

[P] No son tablas obligatorias; son dominios informativos para que el agente pueda decidir cómo representar la información: (1) observaciones originales y procedencia; (2) señales y entidades normalizadas; (3) hipótesis e interpretación científica; (4) contexto territorial y metadatos de capas; (5) evidencias audiovisuales; (6) mediciones e infraestructura; (7) calidad y validación; (8) eventos y relaciones; (9) gestión institucional y actuaciones; (10) participación, conservación y resultados; (11) trazabilidad, permisos de acceso y versiones; (12) datos abiertos derivados. Exportación CSV/JSON/GeoJSON son opciones apropiadas; coordenadas WGS84, fechas ISO 8601 y diccionario de campos con unidad y procedencia. Datos simulados separados e identificados; no exportar PII, evidencias sensibles ni ubicaciones riesgosas sin política correspondiente. No confundir datos abiertos con publicación irrestricta de denuncias.
