# Inventario directo del KMZ entregado por el equipo [K]

Archivo: `Prioridades de Conservación (1).kmz`. SHA-256: `64300f127c811cf11c7718710cd7349878ce80e2fac03193abf5ebca48abe212`. Lectura integral del KML y atributos HTML mediante análisis XML. El ZIP interno contiene `doc.kml` (96.300.428 bytes) y una hoja XSL. Las fechas internas de archivo son 09/05/2025; no prueban la fecha de levantamiento, publicación ni vigencia de la cartografía.

- 14.732 Placemark, todos con MultiGeometry; 17.182 Polygon, 213 anillos interiores; cero geometrías Point o LineString.
- Extensión envolvente (lon mín., lat mín., lon máx., lat máx.): [-75.24952656480643, 10.2587666904547, -74.7208824345115, 11.06300207947404]. Coordenadas KML longitud, latitud, altitud; no confundir la envolvente con límites administrativos o cobertura continua.
- 31 atributos por registro, extraídos de la descripción HTML. No se verificaron validez topológica, solapamientos, superficies únicas, exactitud posicional ni procedencia metodológica. Conteos por Placemark, no hectáreas, municipios ni eventos.
- 3 nombres de zonas hidrográficas; 5 nombres de subzonas; 97 nombres de unidades hidrográficas (no equivale necesariamente a 97 identificadores únicos).

## Atributos principales y significado prudente

| Campo | Interpretación para el contenido |
|---|---|
| FID, FID_ACCION, FID_ESCENA, OBJECTID_1 | Identificadores de capas o cruces; no asumir equivalencia, persistencia o unicidad sin verificación. |
| ZH, NOMZH, SZH, NOMSZH, UH, NOMUH | Códigos y nombres de jerarquías hidrográficas. No son municipios ni especies. |
| Val_Priori | Alto, Medio, Bajo: prioridad territorial, no urgencia de incidente ni salud del manglar. |
| Escenarios, ESC_I, DESC_I, ESC_III, DESC_III, ESC_INT, Escenari_1 | Distintos campos de escenarios y cruces. Conservar diferencias; no fusionarlos como si fueran un único atributo. |
| AccionGen, AccRegiona, AccRegDesc | Acción general, categoría regional y descripción más específica del manejo territorial. No evidencia de actuación realizada. |
| area, Shape_Leng, AREA_HA, Shape_Le_1, Shape_Ar_1 | Magnitudes de geometría/capas; AREA_HA sugiere hectáreas por su nombre, pero verificar unidades, significado y posibles repeticiones. No sumar area o AREA_HA como extensión de manglar. |
| Descripcio | Descripción territorial (prioridad, conectividad, figura legal, etc.). |
| Zona, Cat_Runap, NOM_APC, CAT_APC | Información sobre zonas, RUNAP y portafolios de conservación; vacíos significan dato no informado, no ausencia demostrada. |

## Distribuciones observadas

### Placemark name

| Valor literal | Registros |
|---|---:|
| Bajo Magdalena | 7,561 |
| Caribe - Litoral | 7,079 |
| Rio Magdalena | 92 |


### NOMZH

| Valor literal | Registros |
|---|---:|
| Bajo Magdalena | 7,561 |
| Caribe - Litoral | 7,079 |
| Rio Magdalena | 92 |


### NOMSZH

| Valor literal | Registros |
|---|---:|
| Arroyos Directos al Caribe | 7,079 |
| Canal del Dique | 3,271 |
| Cienaga Mallorquin | 2,329 |
| Directos al Bajo Magdalena entre Calamar y desembocadura al mar Caribe (mi) | 1,961 |
| Rio Magdalena | 92 |


### NOMUH

| Valor literal | Registros |
|---|---:|
| A. Banco | 1,128 |
| A. Grande | 828 |
| A. Viejo | 749 |
| A. Ronco | 594 |
| Plano Costero | 458 |
| C. Ambrosio | 404 |
| Cienaga Mayorquin | 402 |
| C. del Luruaco | 392 |
| A. Quitacalzón | 380 |
| A. Juan de Acosta | 370 |
| A. La Sabana | 368 |
| A. Molineros | 334 |
| C. Balboa | 322 |
| San Luis | 321 |
| Canal del DIque | 311 |
| A. El Astillero | 304 |
| Perdida Cantera | 279 |
| A. Ostion | 274 |
| A. Puente | 267 |
| Cisne | 256 |
| L. San Juan de Tocagua | 230 |
| A. Mendoza | 220 |
| A. Calabrisa | 217 |
| Alto A. Piojo | 216 |
| Cienaga del Totumo | 209 |
| A. Chorro Grande | 208 |
| A. Mapaisero | 207 |
| Complejo Cienagas El Uvero - El Playón | 206 |
| A. El Cojo | 205 |
| A. León | 194 |
| A. Gallego | 175 |
| A. San Juan | 173 |
| A. Sapo | 167 |
| A. Malavet | 167 |
| A. Caiman | 154 |
| A. Camajaru | 150 |
| Ay. Las Piedras | 146 |
| A. Totumito | 143 |
| E. Del  Guajaro | 143 |
| A. Cucambito | 137 |
| A. Las Yeguas - Guavero | 134 |
| Complejo Cienagas Soledad | 120 |
| A. Capote | 110 |
| A. Sin Nombre 7 | 110 |
| A. Blanquice | 109 |
| A. Caja | 99 |
| Rio Magdalena | 92 |
| A. Carreto | 88 |
| A. La Peña | 87 |
| C. Pan de Azucar | 83 |
| A. Arena | 75 |
| Ay. San Blas | 73 |
| A. Cascabel | 70 |
| A.  Caño Fistula | 70 |
| Ay. San Martín | 68 |
| A. Hondo | 65 |
| A. C. Lata | 63 |
| C. Del Rosario | 63 |
| A. Leña | 59 |
| A. Bajo del Loco | 49 |
| A. Caño dulce | 48 |
| A. Orijata | 47 |
| A. Clavelino | 41 |
| Q. Sin Nombre 12 | 35 |
| A. El Polvar | 34 |
| C. Bejuco | 32 |
| A. Juana | 30 |
| A. Guanabano | 26 |
| A. Henequen | 25 |
| A. Sin Nombre 11 | 24 |
| A. Pantano | 23 |
| C. La Poza | 23 |
| A. La Yoya | 21 |
| C. Uvero | 21 |
| A. Sin nombre 3 | 19 |
| Barranquilla | 18 |
| A. Pitalito | 18 |
| A. Palmarito | 17 |
| A. El Diluvio Salado | 17 |
| Ay. Caracolí | 16 |
| A.Mesura | 15 |
| Margen Derecha  Ay. Gallego | 14 |
| A. Sin Nombre 1 | 12 |
| C. Soledad | 11 |
| A. Popo | 10 |
| A. los Piches | 6 |
| A. Sin Nombre 8 | 6 |
| A. El Salao | 6 |
| A. Sin Nombre 9 | 5 |
| A. Sin Nombre 10 | 5 |
| A. Saino | 4 |
| C. Ponderosa | 3 |
| A. Guayepo | 1 |
| A. Sin Nombre 2 | 1 |
| A. Mana | 1 |
| A. Sin Nombre 4 | 1 |
| A. Don Juan | 1 |


### Val_Priori

| Valor literal | Registros |
|---|---:|
| Alto | 6,505 |
| Medio | 5,390 |
| Bajo | 2,837 |


### Escenarios

| Valor literal | Registros |
|---|---:|
| Escenario I | 9,284 |
| Escenario III | 4,624 |
| Escenario II | 824 |


### AccionGen

| Valor literal | Registros |
|---|---:|
| Preservación | 5,815 |
| Restauración | 4,335 |
| Recuperación | 3,898 |
| Rehabilitación | 684 |


### AccRegiona

| Valor literal | Registros |
|---|---:|
| Preservación en áreas naturales  de áreas protegidas y prioridades de conservación | 4,343 |
| Recuperación en áreas transformadas en prioridades de conservación | 2,681 |
| Restauración en áreas semi-naturales de conectividad ecológica regional | 2,138 |
| Restauración en áreas semi-naturales en áreas protegidas y prioridades conservación | 1,859 |
| Preservación en areas naturales de conectividad ecologica regional | 1,197 |
| Recuperación en áreas transformadas de conectividad ecológica regional | 1,043 |
| Rehabilitación en áreas transformadas de áreas protegidas | 402 |
| Restauración en áreas semi-naturales de ecosistemas estratégicos y estratégias complementarias | 338 |
| Preservación en áreas naturales en ecosistemas estrategicos y estrategias complementarias | 275 |
| Rehabilitación en áreas transformadas conectividad ecológica regional | 245 |
| Recuperación en áreas transformadas de ecosistemas estratégicos y estratégias complementarias | 174 |
| Rehabilitación en áreas transformadas de ecosistemas estratégicos y estratégias complementarias | 37 |


### AccRegDesc

| Valor literal | Registros |
|---|---:|
| Preservación en áreas naturales  en prioridades de conservación | 4,133 |
| Recuperación en áreas transformadas en prioridades de conservación | 2,681 |
| Restauración en áreas semi-naturales en prioridades de conservación | 1,407 |
| Restauración en áreas semi-naturales sin ninguna figura legal | 1,394 |
| Recuperación en áreas transformadas en conectividad | 1,043 |
| Preservación en áreas naturales sin ninguna figura legal | 709 |
| Restauración en áreas semi-naturales en conectividad | 683 |
| Restauración en áreas semi-naturales en áreas protegidas | 455 |
| Preservación en áreas naturales en conectividad | 440 |
| Rehabilitación en áreas transformadas de áreas protegidas | 402 |
| Rehabilitación en áreas transformadas en suelos clase VIII | 245 |
| Preservación en áreas naturales  de áreas protegidas | 212 |
| Restauración en áreas semi-naturales en POMCAS | 203 |
| Recuperación en áreas transformadas en POMCAS | 174 |
| Preservación en áreas naturales en POMCAS | 146 |
| Restauración en áreas semi-naturales en rondas hídricas | 127 |
| Preservación en áreas naturales en rondas hídricas | 125 |
| Restauración en áreas semi-naturales en suelos clase VIII | 58 |
| Preservación en áreas naturales en suelos clase VIII | 47 |
| Rehabilitación en áreas transformadas de rondas hídricas | 37 |
| Restauración en áreas semi-naturales en RAMSAR | 8 |
| Preservación en áreas naturales en RAMSAR | 2 |
| Preservación en áreas naturales en Manglar | 1 |


### ESC_I

| Valor literal | Registros |
|---|---:|
| Escenario I | 9,299 |
| (vacío) | 5,433 |


### DESC_I

| Valor literal | Registros |
|---|---:|
| Areas potenciales del SIRAP Caribe | 8,222 |
| (vacío) | 5,433 |
| DMI Palmar - Titi | 558 |
| PNR Los Rosales | 201 |
| RFP El Palomar | 172 |
| DMI Luriza | 120 |
| RNSC_LosCharcones | 26 |


### ESC_III

| Valor literal | Registros |
|---|---:|
| Escenario III | 9,943 |
| (vacío) | 4,789 |


### DESC_III

| Valor literal | Registros |
|---|---:|
| (vacío) | 4,789 |
| Conectividad | 4,267 |
| Áreas naturales y semi-naturales sin ninguna figura legal | 2,456 |
| Suelos | 2,074 |
| Suelos_Conectividad | 1,146 |


### ESC_INT

| Valor literal | Registros |
|---|---:|
| Escenario III | 5,437 |
| Escenario I y II | 3,757 |
| Escenario I, II y III | 3,632 |
| Escenario I | 976 |
| Escenario I y III | 847 |
| Escenario II | 36 |
| Escenario II y III | 33 |
| Escenartio I y III | 14 |


### Escenari_1

| Valor literal | Registros |
|---|---:|
| Escenario I | 9,295 |
| Escenario III | 5,437 |


### Descripcio

| Valor literal | Registros |
|---|---:|
| Prioridades de conservación | 7,153 |
| Conectividad | 2,572 |
| Sin ninguna figura legal | 2,349 |
| Áreas protegidas | 1,007 |
| Prioridades de conservación y POMCAS | 794 |
| Suelos | 512 |
| Prioridades de conservación y rondas hídricas | 240 |
| Áreas protegidas y POMCAS | 41 |
| Prioridades de conservación y suelos | 35 |
| Áreas protegidas y rondas hídricas | 24 |
| Áreas protegidas y conectividad | 2 |
| Áreas protegidas y suelos | 2 |
| Áreas protegidas y Manglar | 1 |


### Zona

| Valor literal | Registros |
|---|---:|
| (vacío) | 13,655 |
| Palmar Titi | 558 |
| PRN Los Rosales | 201 |
| RFP Palomar | 172 |
| DMI Luriza | 120 |
| RNSC Los Charcones | 26 |


### Cat_Runap

| Valor literal | Registros |
|---|---:|
| (vacío) | 13,655 |
| Runap | 1,077 |


### NOM_APC

| Valor literal | Registros |
|---|---:|
| (vacío) | 8,331 |
| Complejo de bosques y arbustales secos del corredor Turbaco-Canalete-Tubará' | 2,632 |
| Complejo de humedales y bosques secos del Guajaro | 1,558 |
| Blanco - Totumo - Bijibana | 1,069 |
| Complejo cenagoso El Totumo y La Venia | 897 |
| Complejo cenagoso de El Uvero-La Poza | 219 |
| Complejo cenagoso del Canal del Dique | 26 |


### CAT_APC

| Valor literal | Registros |
|---|---:|
| (vacío) | 8,331 |
| PRIORIZACION PORTAFOLIO LLANOS, CARIBE, ANDES Y PACIFICO | 5,332 |
| CRA | 1,069 |


## Reglas de interpretación

- Este archivo contiene también bosques secos, humedales, rondas hídricas, suelos y áreas protegidas del interior. No es una máscara de presencia de manglar. Un polígono con prioridad alta no demuestra que haya manglar; uno con prioridad baja no resta urgencia a un incendio.
- Las etiquetas Preservación, Restauración, Recuperación y Rehabilitación representan acciones de gestión territorial asignadas por la capa, no actividades verificadas ni etapas de recuperación de un árbol.
- En `AccRegDesc` aparece un registro con texto específico de manglar y en `Descripcio` uno con Áreas protegidas y Manglar; esto NO implica que solo exista un polígono de manglar en todo el territorio. La cobertura vegetal debe contrastarse con su propia capa.
- Conservar grafías originales, incluidas variantes como Cienaga Mayorquin, Canal del DIque y Escenartio I y III. Alias de presentación no cambian los valores de la fuente.
- Investigar el origen oficial, metodología, fecha efectiva, definición de escenarios, fórmula de prioridad, escala y unidades. El folleto de portafolio CRA es una pista, no demostración de que sea exactamente la metodología de este archivo: https://www.crautonoma.gov.co/documentos/compensaciones/1.1%20Folleto%20Informativo%20Portafolio.pdf
