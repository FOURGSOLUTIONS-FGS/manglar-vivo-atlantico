# Investigación territorial e institucional pendiente

## Fuentes de partida verificadas [W]
- MinAmbiente, Resolución 1263 de 2018, gestión integral de manglares: https://www.minambiente.gov.co/documento-normativa/resolucion-1263-de-2018/
- MinAmbiente, lineamientos de monitoreo (Anexo 5) y SIGMA: https://www.minambiente.gov.co/asuntos-marinos-costeros-y-recursos-acuaticos/manglares/
- INVEMAR, SIGMA: https://museomakuriwa.invemar.org.co/web/sigma . Módulos de estado, presiones, gestión y bienes/servicios. Referencia semántica compatible con observaciones, amenazas, actuaciones y beneficios; no afirmar que el prototipo ya conecta al SIGMA.
- Servicio cartográfico de cobertura SIGMA: https://gis.invemar.org.co/arcgis/rest/services/SIGMA/MANGLARES_COLOMBIA/FeatureServer . Punto de partida para comparar cobertura, no se descargó ni se cruzó aquí.
- Portafolio de conservación CRA: https://www.crautonoma.gov.co/documentos/compensaciones/1.1%20Folleto%20Informativo%20Portafolio.pdf (pista, validar si corresponde al KMZ exacto).

## Investigaciones prioritarias
| Tema | Pregunta que debe resolver la investigación | Resultado documental esperado |
|---|---|---|
| Cobertura | ¿Dónde están las cuatro geometrías del visor mencionadas por Pamela? | Nombre, fuente, versión, fecha, geometría y ámbito; correspondencia o ausencia con sectores del repo. |
| KMZ | ¿Cómo se produjo esta capa y de qué año son sus insumos? | Diccionario oficial, escala, definiciones de prioridad y acciones, relaciones entre escenarios, unidades de áreas y longitudes. |
| Diferencias de conteos | ¿Qué selección o transformación produce los 9.408 registros del repo? | Reconciliación reproducible con los 14.732 Placemark y 17.182 Polygon de [K]; no inferir un filtro sin evidencia. |
| Coberturas estimadas | ¿Qué significan 775, 465, 828 y 262 ha? | Fecha, fuente, definición, superposición, método de estimación, incertidumbre. Separar estimaciones orales de cartografía. |
| Jurisdicción | ¿Qué autoridad interviene en cada sector y fenómeno? | Alcance CRA/Barranquilla Verde/municipios y protocolos vigentes, fuentes jurídicas primarias. |
| Monitoreo nacional | ¿Qué variables, escalas y categorías exige o recomienda el Anexo 5? | Equivalencia de contenido, definiciones y diferencias con observación ciudadana. |
| Datos abiertos | ¿Qué información puede publicarse sin poner en riesgo denunciantes, fauna o expedientes? | Criterios documentados de anonimización, acceso y reserva; separar propuestas de obligaciones jurídicas. |
| Alertas | ¿Qué diferencia institucional existe entre reporte, alerta y expediente? | Procedimientos y requisitos reales; no deducir autorización administrativa por existir una interfaz. |
| Territorio conectado | ¿Qué caños y cuerpos de agua afectan las zonas de manglar? | Relaciones hidrológicas documentadas, no proximidad geométrica como sustituto. |

Prioridad: fuentes CRA, INVEMAR, MinAmbiente, alcaldías y estudios locales. Usar los artículos pertinentes aportados para antecedentes, no para describir el estado de 2026. Citar documento, fecha, página/sección y versión. Si no hay evidencia suficiente, dejar pendiente; no usar una fuente jurídica general para afirmar una competencia puntual.
