# Estado actual por completar con el compañero

Este documento no describe un estado verificado del repositorio actual. La información previamente extraída del repo corresponde a una lectura de `main` del 27/11/2026 sin SHA registrado en este paquete. Los nombres de dominio y subtipos de `04` sirven como referencia histórica. No se han vuelto a consultar ni ejecutado las últimas modificaciones.

Completar con evidencia actual:
- Commit/branch y fecha de corte; fuentes exactas revisadas.
- Contenido realmente disponible para ciudadanos, mentores y CRA: categorías, textos, ejemplos, educación, mapas y campos de interpretación.
- Cambios de vocabulario y significado respecto a `04` y `05`.
- Modelos visuales y datasets: llenar el inventario de `16` con evidencias reales.
- Información que ya puede extraerse, mostrar o corroborar; limitaciones y datos aún desconocidos.
- Capas territoriales realmente usadas, fechas, metadatos y significado; no sumar áreas sin justificar.
- Sensores: integración real, simulación o propuesta. No presentar disponibilidad instrumental no verificada como dato en vivo.
- Distinción de contenido validado, provisional, no implementado y descartado con razón.
- Contradicciones entre documentación, interfaz y comportamiento observado; resolución o incertidumbre explícita.

No convertir esta lista en tickets de implementación. Actualizar el conocimiento para que el equipo tome sus propias decisiones.

## Complemento v2
Reconciliar [K] con capas originales/derivadas que utilice el proyecto. Confirmar si el conteo histórico 9.408 corresponde a un filtro costero, otra versión, geometrías u otra fuente. Registrar clases reales de los modelos y relación con las cuatro especies locales. Completar las investigaciones 21–24 sin inventar resultados; anexar fuentes consultadas.


[A4] Verificar datos de agua públicos efectivamente encontrados, acceso a estaciones y notificaciones realmente disponibles. Reconciliar 27–29 con evidencias actuales.
