# Manglar Vivo Atlántico | fuentes y criterios de certeza

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 0. Procedencia y jerarquía de conocimiento

- **[A1]** Transcripción 08:35: apertura, Pamela Lozano (jefe CTI CRA), Mauricio (organización), Hernando Sánchez Moreno (Universidad Simón Bolívar).
- **[A2]** Transcripción 08:58: plataforma CRA, bases del reto, discusión comunitaria y primera entrevista científica.
- **[A3]** Transcripción 09:32: entrevista a Hernando, Mauricio, funcionaria CRA y entrevista del equipo.
- **[N]** Notas WhatsApp y rúbrica entregadas por el equipo.
- **[E]** Estacion_Mallorquin.pptx, diapositiva 1, reproducción de Anexo G3, diciembre 2024, figura 16 (p. 17; pie en p. 18 según diapositiva).
- **[R]** Repositorio público https://github.com/FOURGSOLUTIONS-FGS/manglar-vivo-atlantico; `src/lib/cra-domain.ts`, `FICHA_TECNICA.md` y `handoff_hackathon_manglares_atlantico.md`, consultados en main el 27/11/2026. Esos documentos describen el prototipo, no constituyen una reglamentación oficial.
- **[B]** Bibliografía científica entregada, referenciada al final.
- **[P]** Propuesta de organización o criterio de interpretación de esta síntesis. No es afirmación atribuible a la CRA ni regla científica validada.

Las transcripciones se han releído, no cotejado acústicamente. Distinguir declaración oral de hecho verificado independientemente; distinguir los resultados de estudios históricos del estado actual. En especial, no convertir ejemplos de mentores en umbrales universales, afirmaciones jurídicas o diagnósticos automáticos. No se ha consultado el Anexo G3 completo ni se ha validado operacionalmente el software.

## Fuentes nuevas
- **[K]** `Prioridades de Conservación (1).kmz`, suministrado por el equipo; inspección directa del KML, conteos y atributos en documento 20. No se dispone de metadatos metodológicos suficientes.
- **[W]** Fuentes externas consultadas para ampliar el contexto científico e institucional, enlaces en documentos 21–23. Diferenciar un hallazgo documentado de una pista de investigación; las guías nacionales no implican que la CRA haya adoptado una regla local concreta.
- **[N2]** Aclaración del equipo: cuatro especies objetivo en el territorio evaluado. La clasificación debe incluir además «no identificable», «otra vegetación/no mangle» y, si procede, varias especies; no añadir especies objetivo de otras regiones sin evidencia local.


- **[A4]** Transcripción adicional aportada en el chat: estaciones conectables, experiencia de foto, repositorios públicos y notificaciones. Extractos relevantes en `29_fuente_A4_extractos_relevantes.md`; hora desconocida, sin cotejo acústico.
