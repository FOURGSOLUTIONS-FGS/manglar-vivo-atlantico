# Las cuatro especies objetivo: contenido ciudadano, visual y científico

[A3,N2] Hernando, audio 09:32, sección de salinidad: cuatro géneros en las áreas revisadas. [W] Alcaldía de Barranquilla confirma las cuatro especies en Mallorquín: https://barranquilla.gov.co/cienaga-de-mallorquin/el-ecosistema-manglar-de-la-cienaga-de-mallorquin . Alcance local; no afirmar que en todo el Caribe colombiano solo existen cuatro especies.

| Especie objetivo | Nombres comunes locales | Rasgos observables orientativos | Contexto ecológico, no regla absoluta |
|---|---|---|---|
| Rhizophora mangle | Rojo | Raíces zancudas, hojas opuestas, propágulos alargados | Bordes inundados, intercambio hídrico; raíces aéreas normales. |
| Avicennia germinans | Negro, salado | Neumatóforos que sobresalen del suelo, hojas con envés más claro | Amplia tolerancia a salinidad, también crece en condiciones menos salinas. |
| Laguncularia racemosa | Blanco, amarillo, bobo (nombre regional variable) | Hojas opuestas ovaladas y glándulas cerca de la base/pecíolo | Puede aparecer en zonas de transición y de regeneración; amarillo en nombre común no implica hojas enfermas. |
| Conocarpus erectus | Zaragoza, botón, botoncillo | Frutos agrupados tipo botón, hojas alternas | Frecuente hacia sectores más terrestres/transicionales. |

Estos rasgos no bastan siempre para la identificación. Combinar hojas, raíces, frutos y contexto; evitar que la IA deduzca especie por color del nombre común. Una foto de paisaje puede contener varias especies y vegetación asociada. No forzar una de las cuatro clases si no se reconoce: especie desconocida, fuera de dominio, otra vegetación, imagen no evaluable. No exigir acercarse a raíces, agua contaminada o zonas peligrosas. No entrenar con cualquier imagen etiquetada solo como mangrove suponiendo que identifica una especie.

## Referencias verificadas y pistas de investigación
- Alcaldía de Barranquilla: inventario divulgativo local de cuatro especies (enlace anterior).
- Smithsonian Tropical Research Institute, Punta Galeta: https://striresearch.si.edu/manglares/tipos-de-manglares/ (comparación morfológica de las mismas cuatro especies, fuera de Colombia).
- MinAmbiente, guía de restauración de manglares, localizar y revisar la sección de tolerancia salina: https://www.minambiente.gov.co/wp-content/uploads/2021/10/Anexo-4.-Guia-de-restauracion-de-ecosistemas-de-manglar-en-Colombia.pdf (pista de investigación, no tabla de umbrales validada en este paquete).
- Paper local 2025: https://doi.org/10.1038/s41598-025-10278-6 . Reporta diferencias de composición, estructura y carbono en estaciones de Mallorquín según condiciones del suelo. La dominancia de una especie no es un medidor directo de salinidad.

## Investigación específica por especie (pendiente)
Para cada una: nombres regionales, rasgos diagnósticos por órgano y estadio, especies confundibles, variación fenológica, hábitat, inundación y sustrato, tolerancia frente a condiciones óptimas, respuesta a salinidad, duración del estrés, mortalidad y recuperación. Buscar fuentes locales primero, luego Caribe colombiano, luego evidencia regional/global etiquetada como extrapolación. Identificar rangos observados, métodos y unidades; no convertir rangos de supervivencia en alarmas. Comprobar licencias, procedencia y cobertura por especie en datasets y resultados de modelos reales. Registrar clase desconocida y ejemplos negativos. No descargar pesos ni entrenar modelos como parte de esta actualización documental.
