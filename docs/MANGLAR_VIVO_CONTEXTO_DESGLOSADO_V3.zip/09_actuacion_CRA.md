# Manglar Vivo Atlántico | actuacion CRA

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 9. Lógica operativa del CRM según entrevistas

[A3] Funcionaria CRA: la gravedad y afectación al ecosistema orientan la prioridad; incendio requiere reacción inmediata y Bomberos; riesgo de fauna activa Grupo PRIA; vertimiento hídrico requiere prueba de agua; equipo de terreno limitado; municipios pueden apoyar; Policía Ambiental puede intervenir primero en hechos presuntamente flagrantes y la CRA después evalúa afectación/restauración. Mauricio dice que el canal puede ser correo o mensaje de texto, sin comprometer un canal específico. Hernando pide IA que ordene información, alerte por importancia y la prepare para decisiones del técnico, incluido contraste normativo sin inventar.

| Naturaleza | Información operativa | Derivación sugerida, no automática ni oficial |
|---|---|---|
| Fuego activo o indicios actuales | hora, lugar, propagación, evidencia disponible | revisión inmediata; Bomberos y coordinación CRA |
| Tala o descarga activa presuntamente infractora | evidencia directa y actualidad, posible permiso desconocido | Policía Ambiental según competencia y decisión; CRA seguimiento |
| Animal herido/atrapado | especie probable, localización y condición | Grupo PRIA según lo indicado en entrevista |
| Mortandad de peces | extensión, actualidad, cantidad, agua, otras señales | evaluación urgente CRA; coordinación fauna según caso |
| Vertimiento / cambio de calidad | descarga, medio receptor, duración, evidencia | inspección y muestreo CRA; apoyo según caso |
| Obstrucción de caños | barrera y conectividad, duración | evaluación técnica CRA, posible municipio |
| Deterioro gradual de dosel / erosión | tendencia, área, contexto espacial | seguimiento técnico y posible inspección |
| Avistamiento / verificación / restauración | método, lugar, fecha, resultado | conocimiento ambiental; no cola de emergencias por defecto |

[P] CRM debe comunicar lo conocido, lo sospechado, qué falta y por qué se prioriza. Diferenciar intensidad del daño, extensión, reversibilidad, persistencia y riesgo de propagación; urgencia puede ser distinta de prioridad de conservación. La autoridad debe confirmar competencia y actuación. No etiquetar personas como infractoras ni prometer alertas externas efectivas sin acuerdo y canal verificados. Emergencia preliminar no tiene que esperar todos los avales para aparecer en bandeja de revisión; emisión oficial y expediente son actos separados. No prescribir tiempo de atención que no haya sido acordado.


[A4] El equipo declara avances de notificación por correo para alertas muy graves; no constituye prueba funcional ni autorización institucional. Ver 28.
