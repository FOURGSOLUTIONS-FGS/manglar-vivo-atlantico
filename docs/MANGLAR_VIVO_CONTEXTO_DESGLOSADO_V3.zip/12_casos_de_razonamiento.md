# Manglar Vivo Atlántico | casos de razonamiento

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 12. Ejemplos de razonamiento que debe aprender la IA

- «A las 12 vi una mancha negra aquí onde estoy»: texto normalizado conserva que se reportó una mancha a las 12; fecha, medio, ubicación del evento y causa desconocidos. Preguntar si fue en agua o suelo y si sigue ahí; no inventar petróleo, vertimiento ni coordenadas. Puede asignar otro o contaminación provisional según esquema.
- «Hay mucha espuma y huele a huevo podrido»: dos señales de fuentes distintas (vista y olfato reportado), posible alteración de calidad, no medición ni prueba de aguas negras. Solicitar ubicación, persistencia, descarga visible si se puede observar sin riesgo.
- «Están talando ahora»: alerta preliminar urgente aunque no haya foto; no afirmar delito ni permiso inexistente; ubicación y corroboración, decisión humana de derivación.
- «Ayer cortaron un árbol, hoy vi el tronco»: acción pasada reportada y evidencia actual distinta; no marcar flagrancia actual.
- «No vi aves»: no detección con esfuerzo desconocido; no declarar ausencia ecológica. «Vi muchas garzas» = presencia reportada, no prueba de calidad química.
- «Mangle seco en área de dosel seco 2026»: coincidencia territorial y observación actual; no identifica causa ni fecha de inicio. Comparar fotos y condiciones hídricas, especie y línea base.
- «Un caño está tapado con tierra y se están secando los árboles»: dos señales relacionadas; posible mecanismo hidrológico; no demostrar causalidad sin evaluación.
- «Plantamos cien mangles»: acción de restauración reportada; supervivencia desconocida. Registro longitudinal separado.
- «Foto sin GPS pero dice dónde hay llamas»: ubicación verbal pendiente de resolver, alerta preliminar urgente. No exigir que vuelva al lugar.
- «Tres reportes del mismo video reenviado»: tres envíos, una pieza de evidencia, independencia no demostrada.
- «Estación sin datos desde ayer»: posible falla de comunicación o equipo, no nivel cero ni contaminación automática.
