# Investigación de reconocimiento visual y contenido por audiencia

Complemento de 04, 05, 15 y 16. El compañero está entrenando modelos visuales con datasets públicos según el equipo; todavía no conocemos sus clases ni métricas.

## Contenido ciudadano por completar
Vocabulario local, imágenes explicativas con licencia, ejemplos cotidianos de amenazas, signos normales confundibles, identificación orientativa de las cuatro especies, observación segura, uso anónimo, observaciones periódicas y conservación. No pedir al ciudadano inferir causas químicas ni identificar especies obligatoriamente.

## Contenido de IA y CRA por completar
| Familia | Qué investigar y reconciliar |
|---|---|
| Especies | Cuatro clases objetivo y no identificable/otra vegetación; rasgos diagnósticos, órganos y etapas. |
| Objetos | Qué objetos reconoce realmente el modelo, qué clases genéricas de datasets no tienen significado ambiental inequívoco. |
| Condiciones | Qué señales visuales están etiquetadas: hojas amarillas, defoliación, agua oscura, espuma, residuos, humo, llamas, animales afectados, etc. |
| Fenómenos | Qué inferencias requieren texto, temporalidad, GPS, inspecciones, sensores o corroboración; no equiparar objeto con evento. |
| Negativos difíciles | Raíces naturalmente visibles, hojarasca normal, agua oscura natural, espuma natural, reflejos, sombras, imágenes de otras regiones. |
| Dataset | Fuente, licencia, geografía, fecha, taxonomía, clase, número de ejemplos, sesgo, duplicados, separación entrenamiento/evaluación. |
| Evaluación | Resultados reales por clase, matriz de confusión si existe, pruebas con imágenes locales, fallos observados y clases no cubiertas. |
| Incertidumbre | Etiqueta desconocida, no evaluable, fuera de distribución; confianza de modelo no equivale a verdad ni gravedad. |
| CRA | Qué señales son relevantes para cada decisión, qué puede ver el funcionario y qué falta confirmar. |

Crear correspondencias muchos-a-muchos entre etiquetas reales de datasets, señales observables, conceptos científicos, vocabulario ciudadano y categorías actuales del CRM; conservar significados no cubiertos por los modelos. No obligar a que una clase visual produzca una denuncia. No modificar código ni entrenar como parte de esta tarea documental. Fuente visual pública no equivale a permiso de redistribución o uso comercial.
