# Respuestas inferidas a las preguntas abiertas

Interpretación de A1–A3 y E. [Evidencia] es declaración/documento aportado, [I] inferencia, [P] propuesta; no convertir ninguna en regla oficial sin validación.

| Pregunta CRA | Respuesta de trabajo | Límite |
|---|---|---|
| Reporte, alerta, expediente | [I] reporte comunica observación; alerta preliminar llama atención; alerta oficial y expediente implican actuación institucional. | Definiciones jurídicas exactas no entregadas. |
| Mínimo para intervenir | [I] fenómeno, ubicación, actualidad y magnitud/evidencia según caso; revisar `05` y `09`. | No exigir todos los datos a una emergencia; mínimos oficiales desconocidos. |
| Gravedad | [Evidencia A3] gravedad y afectación ordenan lista; incendio inmediato. [P] inmediato, prioritario, seguimiento, informativo, indeterminado. | Sin escala oficial ni SLA. |
| Competencia | [Evidencia A3] Bomberos incendio; Grupo PRIA fauna; Policía Ambiental flagrancia; CRA pruebas de agua y evaluación; municipios apoyo. | Jurisdicción y canales concretos pendientes. |
| Emergencia antes de validar | [I/P] visible como preliminar; no emitir alerta oficial automáticamente. | No es autorización de derivación externa. |
| Público/reservado | [I/P] apertura de datos derivados, proteger identidad y evidencias sensibles. | Política de reserva exacta desconocida. |
| Prioridad de conservación | [I] característica territorial, distinta de gravedad; consultar metadatos CRA. | Fórmula y alcance exactos no conocidos. |

| Pregunta Hernando | Respuesta de trabajo | Límite |
|---|---|---|
| Rangos fisicoquímicos | [A3] por especie; ejemplo de Avicennia hasta 80 partes por mil. | Tolerancia no óptimo ni umbral universal. |
| Variabilidad | [A1–A3/B] cuenca vs borde, agua dulce/marina, microtopografía, época y marea. | Sin referencias locales cuantitativas completas. |
| Falsos indicios | [A3/B/I] sulfuro natural por hojarasca, mortalidad aislada, raíces visibles, variación foliar, espuma y color no específicos. | No usar ausencia de fauna o imagen aislada como diagnóstico. |
| Señales combinadas | [I] agua verde+estancamiento; olor+descarga; defoliación+salinidad anómala; caño tapado+secado; mortalidad múltiple. | Hipótesis, no causalidad confirmada. |
| Fotos comparables | [A3] mismo lugar cada ocho días; [P] orientación, encuadre, escala, marea/hora y objeto comparables. | Frecuencia orientativa, no protocolo oficial. |
| Históricos | [A3] imágenes desde 1984, estudios, estaciones con plataforma universitaria, equipos de drones. | Disponibilidad efectiva de series, etiquetas de salud y publicación de drones no demostrada. |
| Salud | [P] condición aparentemente sana, estrés posible, deterioro, mortalidad parcial/extensa, regeneración, indeterminado; restauración como actividad separada. | Sin índice clínico universal ni validación cuantitativa. |

## Conceptualización del producto
[Inferencia, no decisión confirmada] Asistente de clasificación y apoyo científico/operativo; CRA como destinatario de información priorizada y seguimiento ecosistémico; representación dinámica de cada zona como visión potencial basada en evidencia longitudinal. El monitoreo instrumental complementa, no sustituye, ciencia ciudadana. El foco de este paquete es qué conocimiento y contenido existe, no diseñar la solución técnica.
