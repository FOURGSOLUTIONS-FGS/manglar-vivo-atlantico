# Manglar Vivo Atlántico | ecologia y especies

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 2. Modelo mental del ecosistema

[A1,A2,A3,B] Manglar = sistema vivo costero, no solamente árboles. Interactúan agua dulce, agua marina, inundación, sedimento, suelo, vegetación, fauna, microorganismos y actividades humanas. Proporciona protección frente a erosión y tormentas, hábitat y criadero, alimento/ingresos asociados a pesca y almacenamiento de carbono. El valor de protección no equivale automáticamente al costo de una barrera artificial; Barbier (2016) discute valoración por daños evitados.

Hernando considera centrales la hidrología, hidráulica y microtopografía. Hidrología: disponibilidad, circulación, intercambio y régimen de inundación. Hidráulica: caracterización cuantitativa del movimiento, caudales y pulsos. Microtopografía: variación local de elevación que modifica inundación, suelo y condiciones de raíces. Relata montículos alrededor de troncos por sedimentación, con supervivencia diferencial de Avicennia durante sequía en Ciénaga Grande; es experiencia del profesor en otro sistema, no umbral probado para Mallorquín. Potencial redox, salinidad y sulfuros intervienen en las condiciones del sustrato. Los sulfuros pueden producirse por procesos naturales de descomposición y por exceso de carga orgánica; pueden ser fitotóxicos. No asumir que toda presencia indica vertimiento ilegal.

Especies citadas para las zonas del Atlántico: Avicennia, Rhizophora, Laguncularia y Conocarpus. Nombres científicos usuales (complemento taxonómico [B]): Avicennia germinans, Rhizophora mangle, Laguncularia racemosa, Conocarpus erectus. El profesor menciona tolerancia de Avicennia hasta 80 partes por mil como ejemplo, no umbral de salud, no criterio general para todas las especies. No identificar especie con certeza desde cualquier fotografía; registrar género/especie probable o desconocido y evidencia.

Diferenciar manglar de cuenca/laguna (Mallorquín, comunicación con río) de manglar de borde marino (p. ej. zonas de Puerto Colombia). Una señal, como agua verde, tiene relevancia distinta en laguna estuarina versus mar abierto. No extrapolar sin contexto de marea, estación, geomorfología, especie y línea base. El manglar puede perderse o regenerarse por causas humanas y naturales; la migración de cobertura no es necesariamente destrucción ilegal.

Cadena conceptual [P]: presión o mecanismo → cambio de condición ambiental → respuesta biológica → impacto ecosistémico. Cada eslabón debe quedar separado; una fotografía suele observar solo una parte. Ejemplo: barrera en caño → posible menor intercambio → posible cambio de salinidad → posible defoliación. La secuencia es hipótesis a contrastar, no conclusión automática.

## Restricción local explícita
Las cuatro especies objetivo son Rhizophora mangle, Avicennia germinans, Laguncularia racemosa y Conocarpus erectus. El audio A3 y la página de la Alcaldía de Barranquilla coinciden para Mallorquín. No añadir especies de otros países/regiones a la lista objetivo por mera presencia en un dataset. Ver 21 para rasgos y 23 para investigación de rangos. Incluir incertidumbre y vegetación no objetivo, no clasificación forzada.
