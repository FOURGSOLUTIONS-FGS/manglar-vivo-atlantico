# Manglar Vivo Atlántico | reto y necesidades institucionales

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 1. Mandato institucional y problema real

[A1–A3] La CRA necesita información territorial oportuna para tomar decisiones, no solo un mapa de denuncias. No cuenta con vigilancia permanente ni suficientes equipos de campo para intervenir simultáneamente en todo el departamento. Mauricio menciona chatbot, correo y denuncia presencial; un mensaje enviado el viernes puede revisarse el lunes o martes. La latencia tiene consecuencias cuando el daño está ocurriendo. Pamela explica que bancos, colegios, municipios, comunidades y otros actores hacen siembras, limpiezas y actividades, pero no existe una fuente única que centralice qué hicieron, dónde, cuándo y si contribuyó a conservación/restauración.

La plataforma CRA en construcción tiene un visor técnico institucional (extensión, altura, agua, resiliencia, presión antrópica histórica, carbono estimado) y una entrada de registro de actores, acciones, seguimiento y propuestas de proyectos. El reto añade el componente de monitoreo ciudadano. La reglamentación de registro de actores se estaba preparando; no asumir que ya está vigente ni que toda observación espontánea exige registro nominal. INVEMAR es citado como apoyo técnico para contrastar estimaciones con mediciones en terreno. La CRA dijo que no se necesita adquirir/procesar imágenes satelitales en el flujo ciudadano; entregó datos KMZ como insumo de localización. En la presentación se habló de actualizaciones satelitales aproximadamente cada tres semanas, no de datos en vivo garantizados.

### 1.1 Tres preguntas obligatorias

1. ¿Dónde ocurre ahora una amenaza o cambio y con qué nivel de prioridad de conservación coincide?
2. ¿Cómo se valida el dato ciudadano antes de utilizarlo en alerta oficial o expediente, evitando ruido y sabotaje?
3. ¿Cómo sostener participación de escuelas y turistas en el tiempo?

Requisitos: prototipo funcional; geolocalización del suceso; vista de control CRA; muestra de exportación en formato abierto; uso con o sin internet; accesibilidad para no especialistas; enlace de repositorio, ficha técnica (herramientas/modelos IA), video, pitch máximo siete minutos. Entrega 17:00, evaluación hasta 19:30, premiación 20:30, cierre 21:00 según cronograma aportado. Rúbrica [N]: ambiental 25, viabilidad 20, interoperabilidad 15, diseño/inclusión/usabilidad 15, sostenibilidad/escalabilidad 15, presentación 10. El offline conserva la captura; no puede transmitir una alerta sin conectividad. No prometer recepción inmediata en ese caso.

### 1.2 Funciones humanas distintas

Mentor comunitario: conocimiento cotidiano del territorio, accesibilidad, dinámicas locales, conflictos de interés y plausibilidad contextual. Mentor académico: interpretación de fenómenos, variables y métodos de comprobación. Funcionario CRA: evaluación operativa, decisiones administrativas, coordinación y actuaciones. Ciudadano: testigo, participante, observador, no inspector obligado a establecer causa. Universidad: investigación e infraestructura especializada; autoridad: posible continuidad institucional. El doble aval de mentores es una lógica del prototipo [R], no se debe afirmar que es un requisito legal o que la CRA tendrá exactamente ese procedimiento definitivo.
