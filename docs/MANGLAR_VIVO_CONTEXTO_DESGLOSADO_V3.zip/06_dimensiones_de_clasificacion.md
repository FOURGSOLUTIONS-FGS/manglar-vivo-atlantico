# Manglar Vivo Atlántico | dimensiones de clasificacion

Corte documental: 27/11/2026. Contexto de contenido; no prescribe arquitectura. Etiquetas de fuente en `00_fuentes_y_criterios_de_certeza.md`.

## 6. Variables ortogonales para interpretar cada dato

[P] Mantener por separado: finalidad (reporte de amenaza / observación de biodiversidad / monitoreo repetido / verificación territorial / acción de conservación / medición); medio (agua, suelo, dosel, fauna, infraestructura, mixto, desconocido); señal; mecanismo hipotético (hídrico, químico, biológico, físico, intervención directa, desconocido); origen (natural, humano, mixto, indeterminado); actividad (activa, finalizada, persistente, histórica, desconocida); tiempo de observación, captura, envío y recepción; alcance (individual/múltiple, área o cantidad cuando existe); evidencia; lugar; prioridad territorial; gravedad; urgencia; validación; decisión administrativa.

El valor desconocido no equivale a falso, cero, ausente, normal ni descartado. Distinguir observación directa, información de terceros, opinión, hipótesis, dato medido y hecho verificado. Registrar negación y temporalidad: «no hay fuego», «ayer hubo fuego», «creo que hay fuego» y «hay fuego ahora» son diferentes. No aumentar gravedad porque el ciudadano emplea lenguaje alarmista ni disminuirla por mala ortografía. No eliminar texto original; una corrección de estilo no agrega hechos.
