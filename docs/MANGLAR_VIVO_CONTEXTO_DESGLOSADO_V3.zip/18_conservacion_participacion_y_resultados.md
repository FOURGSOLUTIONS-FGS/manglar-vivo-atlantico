# Participación, conservación y resultados

[A1/A2] Pamela explica la ausencia de fuente central que reúna actores, actividades, seguimiento y propuestas. La intervención de actores es distinta de la observación espontánea. La formalización del registro estaba en preparación: no afirmar obligatoriedad legal vigente.

| Actividad | Contenido de interés | Resultado distinto de actividad |
|---|---|---|
| Siembra | Especie, ubicación, fecha, cantidad, actor | Supervivencia y establecimiento |
| Limpieza | Lugar, tipos y cantidad aproximada de residuos | Persistencia de la reducción de basura |
| Recuperación hídrica | Caño, acción, fecha, conectividad | Cambios en circulación y condiciones ambientales |
| Restauración de cobertura | Área, objetivos y acciones | Regeneración, condición y evolución del bosque |
| Educación | Comunidad/colegio, participación, tema | Continuidad y aprendizaje, si se mide |
| Monitoreo | Punto, frecuencia, fenómeno observado | Datos comparables y cambios documentados |
| Investigación | Estudio, lugar, método, procedencia | Hallazgos y límites |

[P] Para escuelas: adopción de puntos, observaciones repetidas, seguimiento de resultados. Para turistas: contribuciones breves y contexto educativo. Para comunidades: conocimiento local y continuidad. No confundir premios por participación con credibilidad científica; privilegiar calidad y persistencia frente a volumen. No divulgar identidades sensibles. No atribuir impacto de restauración a una actividad sin seguimiento. No calcular carbono capturado por árbol sembrado sin metodología.
